    /*
         * To change this license header, choose License Headers in Project Properties.
         * To change this template file, choose Tools | Templates
         * and open the template in the editor.
     */
    package hospital;

    import java.io.File;
    import java.io.FileNotFoundException;
    import java.util.Scanner;

    /**
     *
     * @author Karunakar Reddy Katasani
     */
    public class HospitalDriver {

        /**
         * @param args the command line arguments
         */
        public static void main(String[] args) throws FileNotFoundException {
            // TODO code application logic here
            Scanner sc = new Scanner(new File("input.txt"));
            String docname;
            String SpecialityType;
            String officeHours;
            String hospitalName;
            String hospitalAddress;
            AbstractHospitalInfo hospitalInfo = new OutPatient();
            hospitalName = sc.nextLine();
            hospitalAddress = sc.nextLine();
            System.out.println("****************************************\n"
                    + "Patient Details: \n"
                    + "****************************************");
            while (sc.hasNext()) {
                String doctor = sc.nextLine();
                if (doctor.equalsIgnoreCase("Doctor")) {
                    docname = sc.nextLine();

                    SpecialityType = sc.nextLine();

                    officeHours = sc.nextLine();

                    Doctor dr = new Doctor(docname, SpecialityType, officeHours);
                    try {
                        hospitalInfo.addDoctors(dr);
                        throw new InvalidDoctorSizeException();
                    } catch (InvalidDoctorSizeException e) {

                    }

                } else {
                    char gender = doctor.charAt(0);

                    int age = Integer.valueOf(sc.nextLine());
                    String first_name = sc.nextLine();

                    String last_name = sc.nextLine();
                    int insurance_id = Integer.valueOf(sc.nextLine());
                    String doctortovisit = sc.nextLine();

                    Patient patient = new Patient(first_name, last_name, insurance_id, age, gender, doctortovisit);
                    OutPatient outpatient = new OutPatient(hospitalName, hospitalAddress, patient);
                    System.out.println(outpatient.toString());

                    hospitalInfo.assignPatientsToDoctor(hospitalInfo.getAvailableDoctorsList(), patient);
                    String billingDetails = sc.nextLine();
                    double billGenerated = outpatient.calcBill(billingDetails);

                    outpatient.calcBill(billingDetails);
                    System.out.println("Bill Amount Generated before Insurance deduction:" + billGenerated);
                    String InsuranceCompany = sc.nextLine();
                    double InsuranceCoverage = Double.valueOf(sc.nextLine());
                    String inusrancePlanName;
                    double premiumPaid;
                    if (age < 16) {
                        ChildInsurance childInsurance = new ChildInsurance(InsuranceCompany, InsuranceCoverage, first_name, last_name, insurance_id, age, gender, doctortovisit);
                        System.out.println(childInsurance.toString());

                        premiumPaid = Double.valueOf(sc.nextLine());

                        try {
                            inusrancePlanName = childInsurance.checkHealthInsurancePlan();
                            System.out.println("Insurance Plan Name: " + inusrancePlanName);
                            throw new InvalidInsuranceIDException();
                        } catch (InvalidInsuranceIDException e) {

                        }
                        try {
                            double amountPayable = childInsurance.calcAmountPayableToHospital(premiumPaid, billGenerated);
                            System.out.println("Amount to be paid by after insurance deduction: " + amountPayable);
                            System.out.println("****************************************");
                            

                            throw new NegativeAmountException();
                        } catch (NegativeAmountException e) {

                        }
                    } else {
                        AdultInsurance adultInsurance = new AdultInsurance(InsuranceCompany, InsuranceCoverage, first_name, last_name, insurance_id, age, gender, doctortovisit);
                        System.out.println(adultInsurance.toString());
                        premiumPaid = Double.valueOf(sc.nextLine());
                        try {
                            inusrancePlanName = adultInsurance.checkHealthInsurancePlan();
                            System.out.println("Insurance Plan Name: " + inusrancePlanName);
                        } catch (InvalidInsuranceIDException e) {
                            
                        }
                        try {
                            double amountPayable = adultInsurance.calcAmountPayableToHospital(premiumPaid, billGenerated);
                            System.out.println("Amount to be paid by after insurance deduction: " + amountPayable);
                           

                            throw new NegativeAmountException();
                        } catch (NegativeAmountException e) {

                        }

                    }
                    System.out.println("****************************************");
                }
            }

            System.out.println("****************************************\n"
                    + "Patients assigned to doctor \"Lisa DiStefano\": \n"
                    + "****************************************");

            for (Doctor t : hospitalInfo.getPatientsMappedToDoctor().keySet()) {

                if (t.getName().equals("Lisa DiStefano")) {
                    System.out.println(hospitalInfo.getPatientsMappedToDoctor().get(t));
                }
            }

        }

    }
