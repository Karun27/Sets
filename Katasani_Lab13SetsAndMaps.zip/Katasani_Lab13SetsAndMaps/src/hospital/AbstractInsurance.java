    /*
             * To change this license header, choose License Headers in Project Properties.
             * To change this template file, choose Tools | Templates
             * and open the template in the editor.
     */
    package hospital;

    /**
     *
     * @author Karunakar Reddy Katasani
     */
    public class AbstractInsurance extends Patient implements Insurance {

        private String InsuranceCompanyName;
        private double InsuranceCoverage;

        public AbstractInsurance(String InsuranceCompanyName, double InsuranceCoverage, String fName, String lName, int insuranceID, int age, char gender, String doctorToVisit) {
            super(fName, lName, insuranceID, age, gender, doctorToVisit);
            this.InsuranceCompanyName = InsuranceCompanyName;
            this.InsuranceCoverage = InsuranceCoverage;
        }

        public String getInsuranceCompanyName() {
            return InsuranceCompanyName;
        }

        public double getInsuranceCoverage() {
            return InsuranceCoverage;
        }

        @Override
        public String checkHealthInsurancePlan() throws InvalidInsuranceIDException {
            if (getInsuranceID() > 0 & getInsuranceID() < 10000) {
                return "Health maintenance organizations (HMOs) plan";
            } else if (getInsuranceID() >= 10000 & getInsuranceID() < 20000) {
                return "Preferred provider organizations (PPOs) plan";
            } else if (getInsuranceID() >= 20000 & getInsuranceID() < 30000) {
                return "Point-of-service (POS) plan";
            } else if (getInsuranceID() >= 30000 & getInsuranceID() < 40000) {
                return "High-deductible health plans (HDHPs)";
            } else {
                throw new InvalidInsuranceIDException();
            }
        }

        @Override
        public double calcAmountPayableToHospital(double PremiumPaid, double billGenerated) throws NegativeAmountException {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    }
