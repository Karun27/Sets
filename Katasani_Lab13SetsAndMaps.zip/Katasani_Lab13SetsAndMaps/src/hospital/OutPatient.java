    /*
             * To change this license header, choose License Headers in Project Properties.
             * To change this template file, choose Tools | Templates
             * and open the template in the editor.
     */
    package hospital;

    import java.util.HashSet;
    import java.util.List;

    /**
     *
     * @author Karunakar Reddy Katasani
     */
    public class OutPatient extends AbstractHospitalInfo {

        private Patient patient;

        public OutPatient() {

        }

        public OutPatient(String hospitalName, String hospitalAddress, Patient patient) {
            super(hospitalName, hospitalAddress);
            this.patient = patient;
        }

        @Override
        public double calcBill(String billingDetails) {
            double bill = 0;
            String[] items = billingDetails.split(",");
            for (String item : items) {
                if (item != null) {
                    if (item.equalsIgnoreCase("Diphtheria")) {
                        bill = bill + 10.25;
                    } else if (item.equalsIgnoreCase("Tetanus")) {
                        bill = bill + 12.99;
                    } else if (item.equalsIgnoreCase("Acellular pertussis")) {
                        bill = bill + 17.89;
                    } else if (item.equalsIgnoreCase("Haemophilus influenzae")) {
                        bill = bill + 7.5;
                    } else if (item.equalsIgnoreCase("Pneumococcal conjugate")) {
                        bill = bill + 9.9;
                    } else {
                        bill = bill + EMERGENCY_FEE;
                    }

                }

            }
            bill = bill + BASE_CONSULTATION_FEE;
            return bill;
        }

        @Override
        public void assignPatientsToDoctor(List<Doctor> doctorList, Patient patient) {

            for (int i = 0; i < doctorList.size(); i++) {

                if (patient.getDoctorToVisit().equalsIgnoreCase(String.valueOf(doctorList.get(i)))) {

                    if (getPatientsMappedToDoctor().get(doctorList.get(i)) == null) {
                        getPatientsMappedToDoctor().put(doctorList.get(i), new HashSet());
                    }
                    getPatientsMappedToDoctor().get(doctorList.get(i)).add(patient);

                }

            }
        }

        @Override
        public String toString() {
            return super.toString() + "\n" + patient;
        }

    }
